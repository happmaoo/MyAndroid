<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

    <div class="col-mb-12">

        <div class="error-page">
            <h2 class="post-title">404 - 页面没找到</h2>
            <p>你想查看的页面已被转移或删除了, 要不要搜索看看:</p>
      <div class="d-flex align-items-center">
		<form class="form-inline mt-2 mt-md-0" action="./">
        <input class="form-control mr-sm-2" placeholder="请输入文字..." name="s" aria-label="Search" type="text">
        <button class="btn my-2 my-sm-0" type="submit">搜索</button>
      	</form>
      </div>
        </div>

  </div><!-- /.row -->

</main>

<?php $this->need('footer.php'); ?>
