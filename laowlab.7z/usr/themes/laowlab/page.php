<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="col-lg-9 blog-main">
<h3 class="archive-title"><?php $this->title() ?></h3>

<?php $this->content(); ?>

</div>
 

<?php $this->need('sidebar.php'); ?>
<!--sidebar-->

  </div><!-- /.row -->

</main>

<?php $this->need('footer.php'); ?>