<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<footer class="blog-footer part-4">
<div class="footer-part1">
<div class="container"><div class="row">

<div class="col-md-4">
	<div class="about">
		<p class="img"></p>
		<p class="txt">老王研究所是一个专注于分享实用软件和技巧的博客，关注我们，让你的生活和工作充满效率。</p>
	</div>
</div>
<div class="col-md-4">
	
</div>
<div class="col-md-4"><h3 class="f-tit">关注我们</h3>
<div class="follow">
	<a class="wx" href="#" title="微信" data-toggle="modal" data-target="#followModal"></a>
	<a class="wb" href="https://weibo.com/happmaoo" target="_blank" title="微博"></a>
	<a class="bi" href="https://space.bilibili.com/8286319" target="_blank" title="哔哩哔哩"></a>
	<a class="yk" href="http://i.youku.com/u/UMTIyMjcwNDA4" target="_blank" title="优酷"></a>
	<a class="yt" href="https://www.youtube.com/channel/UCw169oQjr4AaVWOvVh2VgUg" target="_blank" title="Youtube"></a>
	<a class="tw" href="https://twitter.com/laowlabcom" target="_blank" title="Twitter"></a>
</div>
</div>

</div></div>
</div>

<div class="footer-part2">
  <p>&copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>.
    我们只分享最实用的软件.</p>
  <p>
    <a href="#">返回顶部</a>
  </p>
</div>
  
</footer>







<!-- Modal -->
<div class="modal fade" id="followModal" tabindex="-1" role="dialog" aria-labelledby="followModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="followModalLabel">关注我们</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">



<ul class="nav nav-tabs" id="followTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="follow-wx-tab" data-toggle="tab" href="#follow-wx" role="tab" aria-controls="follow-wx" aria-selected="true">微信公众号</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="follow-wx2-tab" data-toggle="tab" href="#follow-wx2" role="tab" aria-controls="follow-wx2" aria-selected="false">微信个人号</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="follow-qq-tab" data-toggle="tab" href="#follow-qq" role="tab" aria-controls="follow-qq" aria-selected="false">交流QQ群</a>
  </li>
</ul>
<div class="tab-content" id="followTabContent">
  <div class="tab-pane fade show active" id="follow-wx" role="tabpanel" aria-labelledby="follow-wx-tab"><span class="img"></span></div>
  <div class="tab-pane fade" id="follow-wx2" role="tabpanel" aria-labelledby="follow-wx2-tab"><span class="img"></span></div>
  <div class="tab-pane fade" id="follow-qq" role="tabpanel" aria-labelledby="follow-qq-tab"><p class="img"></p><p>QQ群号: 216099288</p></div>
</div>





      </div>
    </div>
  </div>
</div>
<!-- / Modal -->






<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script type="text/javascript" src="<?php $this->options->themeUrl('js/jquery-2.1.3.min.js'); ?>"></script>
<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="<?php $this->options->themeUrl('bootstrap/js/bootstrap.min.js'); ?>"></script>

<script src="<?php $this->options->themeUrl('js/m.js'); ?>"></script>

<?php $this->footer(); ?>
</body>
</html>
