<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

    <div class="col-lg-9 blog-main">


        <h3 class="archive-title"><?php $this->archiveTitle(array(
            'category'  =>  _t('关于 %s 的文章:'),
            'search'    =>  _t('包含关键字 %s 的文章:'),
            'tag'       =>  _t('关于 %s 的文章:'),
            'author'    =>  _t('%s 发布的文章:')
        ), '', ''); ?></h3>
        <?php if ($this->have()): ?>

<?php while($this->next()): ?>
	<article class="post-list">

		<div class="post-list-entry">
				<h2 class="entry-title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
			<a class="thumbnail-link" href="<?php $this->permalink() ?>">
				<div class="thumbnail-wrap">
					<img src="<?php @thumbnail($this); ?>" alt="<?php $this->title() ?>"/>
				</div>
				<!-- .thumbnail-wrap -->
			</a>
			<div class="entry-overview">

				<div class="entry-meta">	<span class="entry-category"><?php $this->category(','); ?></span><span class="entry-tags"><?php $this->tags('', true, 'none'); ?></span>
			<span class="entry-date"><time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php $this->date('Y-m-d'); ?></time></span>
			<span class="meta-right">

				<span class="entry-comment"><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('没有评论', '1 条评论', '%d 条评论'); ?></a></span>
		</span>
					<!-- .meta-right -->
				</div>
				<!-- .entry-meta -->
				<div class="entry-summary">
					<p><?php $this->excerpt(120, '...'); ?></p>
				</div>
				<!-- .entry-summary -->
			</div>
			<!-- .entry-overview -->
		</div>



	</article>
<?php endwhile; ?>

        <?php else: ?>
            <article class="post">
                <h2 class="post-title"><?php _e('没有找到内容'); ?></h2>
            </article>
        <?php endif; ?>




      <nav class="blog-pagination">
        <?php $this->pageNav('上一页', '下一页', 1, '...', array('wrapTag' => 'ol', 'wrapClass' => 'page-navigator', 'itemTag' => 'li', 'textTag' => 'span', 'currentClass' => 'current', 'prevClass' => 'prev', 'nextClass' => 'next',)); ?>
      </nav>

    </div><!-- /.blog-main -->

<?php $this->need('sidebar.php'); ?>
<!--sidebar-->

  </div><!-- /.row -->

</main>

<?php $this->need('footer.php'); ?>
