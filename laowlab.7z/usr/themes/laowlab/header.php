<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s 下的文章'),
            'search'    =>  _t('包含关键字 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
            'author'    =>  _t('%s 发布的文章')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>

<!-- 新 Bootstrap 核心 CSS 文件 -->
<link rel="stylesheet" href="<?php $this->options->themeUrl('bootstrap/css/bootstrap.min.css'); ?>">

<!-- 可选的Bootstrap主题文件（一般不用引入） -->
<link rel="stylesheet" href="<?php $this->options->themeUrl('bootstrap/css/bootstrap-theme.min.css'); ?>">

<link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">

    <!-- 通过自有函数输出HTML头部信息 -->
    <?php $this->header(); ?>

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-9592953235994353",
          enable_page_level_ads: true
     });
</script>

</head>
<body>
<!--[if lt IE 8]>
    <div class="browsehappy" role="dialog"><?php _e('当前网页 <strong>不支持</strong> 你正在使用的浏览器. 为了正常的访问, 请 <a href="http://browsehappy.com/">升级你的浏览器</a>'); ?>.</div>
<![endif]-->


<header class="part-1">
  <div class="navbar navbar-white bg-white">
    <div class="container d-flex justify-content-between">
      <a href="/" class="navbar-brand d-flex align-items-center">
        首页
      </a>

  <nav class="my-2 my-md-0 mr-md-3">
				<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
				<?php while($pages->next()): ?>
				<a class="p-2"<?php if($this->is('page', $pages->slug)): ?> class="current p-2"<?php endif; ?> href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
				
				<?php endwhile; ?>
  </nav>

    </div>
</div>
</header>


<!-- header -->
<div class="container part-2">
  <header class="blog-header py-3">
    <div class="row  justify-content-between align-items-center">
      <div class="col-md-4 text-center">
        <a class="blog-header-logo text-dark" href="/" title="老王研究所">老王研究所</a>
      </div>
      <div class="col-md-4 pt-1 align-items-center g-head-1">
        <a class="" href="#" title=""> 广告位 </a>
      </div>
      <div class="col-md-4 d-flex align-items-center search">
		<form class="form-inline mt-2 mt-md-0" action="./">
        <input class="form-control mr-sm-2" placeholder="请输入文字..." name="s" aria-label="Search" type="text">
        <button class="btn my-2 my-sm-0" type="submit">搜索</button>
      	</form>
      </div>
    </div>
  </header>

  <div class="catalog">
		<?php $this->widget('Widget_Metas_Category_List')->listCategories('wrapClass=nav d-flex'); ?>
  </div>
<!--
  <div class="row mb-2">
    <div class="col-md-12">
      <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-primary">World</strong>
          <h3 class="mb-0">Featured post</h3>
          <div class="mb-1 ">Nov 12</div>
          <p class="card-text mb-auto">This is a wider card with supporting text below as a natural lead-in to additional content.</p>
          <a href="#" class="stretched-link">Continue reading</a>
        </div>
        <div class="col-auto d-none d-lg-block">
          <svg class="bd-placeholder-img" width="400" height="250" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#999"></rect><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
        </div>
      </div>
    </div>
  </div>
-->
  
</div>

<!-- header end -->

<main role="main" class="container part-3">
  <div class="row">