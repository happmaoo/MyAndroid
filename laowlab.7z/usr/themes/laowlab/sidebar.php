<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
    <aside class="col-lg-3 blog-sidebar">
 
<div class="widget widget_ ">
<h2 class="widget-title">最新文章</h2>
	        <ul class="panel-body widget_list">
	            <?php $this->widget('Widget_Contents_Post_Recent')
	            ->parse('<li><span></span><a href="{permalink}">{title}</a></li>'); ?>
	        </ul>
</div>

<div class="widget widget_ ">
<h2 class="widget-title">最新评论</h2>
	        <ul class="panel-body widget_list">
	        <?php $this->widget('Widget_Comments_Recent')->to($comments); ?>
	        <?php while($comments->next()): ?>
	            <li><a href="<?php $comments->permalink(); ?>"><?php $comments->author(false); ?></a>: <?php $comments->excerpt(35, '...'); ?></li>
	        <?php endwhile; ?>
	        </ul>
</div>

<div class="widget widget_ ">
<h2 class="widget-title">分类</h2>
<?php $this->widget('Widget_Metas_Tag_Cloud',array('limit' => 100))->to($tags);  ?>  
<?php while($tags->next()): ?>  
<a rel="tag" class="tag <?php tagsrandom();?>" href="<?php $tags->permalink(); ?>"><?php $tags->name(); ?></a>
<?php endwhile; ?>
</div>

<div class="widget widget_qr ">
<h2 class="widget-title">微信扫一扫，关注我们</h2>
<img class="image " src="/usr/themes/laowlab/img/QR.png" title="扫一扫关注微信">
</div>



</aside><!-- /.blog-sidebar -->