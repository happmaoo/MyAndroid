<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="col-lg-9 blog-main">
      <div class="blog-post">
        <h2 class="blog-post-title"><?php $this->title() ?></h2>
        <div class="blog-post-meta">
<span class="meta-category"><?php $this->category(','); ?></span>
<span class="meta-tags"><?php $this->tags('', true, 'none'); ?></span>
<time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php $this->date('Y-m-d'); ?></time>
<span class="meta-comments"><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('没有评论', '1 条评论', '%d 条评论'); ?></a></span>
	    </div>
        
		<?php $this->content(); ?>

      </div><!-- /.blog-post -->
	  <div class="post-tools container"> <div class="row">
<div class="tool-follow col-md-6">


<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="wx-tab" data-toggle="tab" href="#wx" role="tab" aria-controls="wx" aria-selected="true">微信</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="qq-tab" data-toggle="tab" href="#qq" role="tab" aria-controls="qq" aria-selected="false">QQ群</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">更多</a>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="wx" role="tabpanel" aria-labelledby="wx-tab">
	  <span class="img"></span><span class="txt">扫描关注微信，加入研究所小组，第一时间获取新鲜内容。</span>
  </div>
  <div class="tab-pane fade" id="qq" role="tabpanel" aria-labelledby="qq-tab">
	  <span class="img img2"></span><span class="txt">打开手机QQ扫描加入QQ群 (群号: 216099288)，讨论和分享最新的实用技巧。</span>
  </div>
  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
	  <span class="txt">更多关注方法请看页面底部 关注我们。</span>
  </div>
</div>


	
</div>

<div class="share col-md-6"> <!-- dynamic loading js here --> </div>


	  </div></div> <!-- / post-tools -->
	  
      <nav class="blog-pagination">
 
      </nav>
      
<?php $this->need('comments.php'); ?>



    </div><!-- /.blog-main -->

<?php $this->need('sidebar.php'); ?>
<!--sidebar-->

  </div><!-- /.row -->

</main>

<?php $this->need('footer.php'); ?>
