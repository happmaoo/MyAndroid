//-------------------------------- UEditor 插入下载链接 --------------------------------------------------
//$("#edit-secondary").prepend("<div onclick='ue1.setContent(\"xxxxxxxxxxxxxxx\")'>xxx</div>");
//ue1.getAllHtml();


//利用注释实现js多行字符串。
Function.prototype.getMultiLine = function() { 
    var lines = new String(this); 
    lines = lines.substring(lines.indexOf("/*") + 3, lines.lastIndexOf("*/")); 
    return lines; 
} 
var txt = function() { 
    /*
    <h4 style="color:#0D8900;">MyTools_insertDownloadLink(UEditor)</h4>
    <input style="" type="text" name="" id="name" value=""/><-Name<br/>
    <input type="text" name="" id="link" value=""/><-Link<br/><br/>
    <span style="border:1px solid #aaa;background:#eee;padding:5px;margin:5px;" onclick='javascript:add()'>插入链接</span>
    */ 
} 
function add(){

	var lname = $("#name").val();if(lname==""){lname="点击下载"}
	var llink = $("#link").val();if(llink==""){alert("链接不能为空.");return false;}
	ue1.setContent("<a href=\""+llink+"\" class=\"download_link\">"+lname+"</a>",true);
		
	
}
  
 

//document.write(ffff.getMultiLine());

$("#edit-secondary").after(txt.getMultiLine());
//-------------------------------- end UEditor 插入下载链接 --------------------------------------------------

$(function($) {

//$("#edit-secondary").load("insertDownloadLink.html");

});